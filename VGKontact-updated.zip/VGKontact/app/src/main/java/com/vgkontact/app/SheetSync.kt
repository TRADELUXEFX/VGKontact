package com.vgkontact.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** A single row as stored in the Google Sheet. */
data class ContactRow(
    val whatsapp: String,
    val referral: String,
    val timestamp: String
)

/** One day's worth of additions, e.g. { date = "2026-08-23", count = 6 }. */
data class DayCount(
    val date: String,
    val count: Int
)

/** Full history summary: all-time total plus a per-day breakdown, most recent first. */
data class HistorySummary(
    val total: Int,
    val days: List<DayCount>
)

/**
 * Sends the collected numbers to a Google Sheet via a Google Apps Script
 * "Web App" endpoint. This is the simplest way to write rows into a Sheet
 * from an app without setting up OAuth / a service account.
 *
 * Setup (one-time, on the Google side):
 * 1. Create a Google Sheet with header row: WhatsApp Number | Referral Number | Timestamp
 * 2. Extensions -> Apps Script, paste the script from apps-script/Code.gs
 *    (included in this project) and deploy it as a Web App
 *    ("Execute as: Me", "Who has access: Anyone").
 * 3. Paste the deployment URL below.
 */
object SheetSync {

    // TODO: replace with your deployed Apps Script Web App URL
    private const val ENDPOINT_URL = "https://script.google.com/macros/s/AKfycbxXy1QFBK5VANJXZhfPwVfzw888PDMmUq74SCa4jPr4nSM6uWz1dgvGDXAWAhYSHMVA/exec"

    suspend fun submit(whatsappNumber: String, referralNumber: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                    .format(Date())

                val params = listOf(
                    "whatsapp" to whatsappNumber,
                    "referral" to referralNumber,
                    "timestamp" to timestamp
                ).joinToString("&") { (key, value) ->
                    "$key=${URLEncoder.encode(value, "UTF-8")}"
                }

                val connection = URL(ENDPOINT_URL).openConnection() as HttpURLConnection
                connection.requestMethod = "POST"
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                connection.outputStream.use { it.write(params.toByteArray()) }

                val code = connection.responseCode
                connection.disconnect()

                if (code in 200..299) Result.success(Unit)
                else Result.failure(Exception("Server responded with $code"))
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    /** A contact read from the device address book, ready to be submitted. */
    data class DeviceContact(
        val name: String,
        val phoneNumber: String
    )

    /** Result summary of a bulk-import run: how many succeeded vs failed. */
    data class ImportResult(
        val submitted: Int,
        val failed: Int
    )

    /**
     * Submits a full batch of device contacts in one go, reusing the same
     * Apps Script endpoint as the single-number submit(). Each contact is
     * posted as its own row (name goes in the referral column so existing
     * Sheet formulas/history counts keep working unmodified).
     * Failures for individual contacts don't stop the batch; they're just
     * counted so the UI can report a partial result.
     */
    suspend fun importAllContacts(contacts: List<DeviceContact>): ImportResult =
        withContext(Dispatchers.IO) {
            var submitted = 0
            var failed = 0

            for (contact in contacts) {
                val result = submit(
                    whatsappNumber = contact.phoneNumber,
                    referralNumber = contact.name
                )
                if (result.isSuccess) submitted++ else failed++
            }

            ImportResult(submitted = submitted, failed = failed)
        }

    /** Fetches the first [limit] rows already saved in the Sheet, for the preview list. */
    suspend fun fetchPreview(limit: Int = 10): Result<List<ContactRow>> =
        withContext(Dispatchers.IO) {
            try {
                val connection = URL("$ENDPOINT_URL?limit=$limit").openConnection() as HttpURLConnection
                connection.requestMethod = "GET"

                val code = connection.responseCode
                val body = if (code in 200..299) {
                    connection.inputStream.bufferedReader().use { it.readText() }
                } else null
                connection.disconnect()

                if (body == null) return@withContext Result.failure(Exception("Server responded with $code"))

                val jsonArray = JSONArray(body)
                val rows = (0 until jsonArray.length()).map { i ->
                    val obj = jsonArray.getJSONObject(i)
                    ContactRow(
                        whatsapp = obj.optString("whatsapp"),
                        referral = obj.optString("referral"),
                        timestamp = obj.optString("timestamp")
                    )
                }
                Result.success(rows)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    /** Fetches the all-time total plus a day-by-day breakdown of Kontacts added. */
    suspend fun fetchHistory(): Result<HistorySummary> =
        withContext(Dispatchers.IO) {
            try {
                val connection = URL("$ENDPOINT_URL?action=history").openConnection() as HttpURLConnection
                connection.requestMethod = "GET"

                val code = connection.responseCode
                val body = if (code in 200..299) {
                    connection.inputStream.bufferedReader().use { it.readText() }
                } else null
                connection.disconnect()

                if (body == null) return@withContext Result.failure(Exception("Server responded with $code"))

                val obj = org.json.JSONObject(body)
                val total = obj.optInt("total", 0)
                val daysArray = obj.optJSONArray("days") ?: JSONArray()
                val days = (0 until daysArray.length()).map { i ->
                    val dayObj = daysArray.getJSONObject(i)
                    DayCount(
                        date = dayObj.optString("date"),
                        count = dayObj.optInt("count", 0)
                    )
                }
                Result.success(HistorySummary(total = total, days = days))
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
}
